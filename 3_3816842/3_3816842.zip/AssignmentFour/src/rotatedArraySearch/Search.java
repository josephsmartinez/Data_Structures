/** *******************************************************************
 * Purpose/Description: Given a sorted array of N distinct integers that
 * has been rotated an unknown number of times.
 * Implement (in Java) an efficient algorithm that finds an element in the array
 * Author’s Panther ID: 3816842
 * Certification: I hereby certify that this work
 * is my own and none of it is the work of any other person.
 *******************************************************************
 */
package rotatedArraySearch;

import java.util.Arrays;

/**
 * @author josemart
 */
public class Search {

    /**
     *
     * @param list array of integers
     * @param key the number to look for
     * @return the index of the element found
     */
    static int search(int[] list, int key) {
        //Find the pivot
        int pivot = findPivot(list, 0, list.length -1);
        print("Pivot is: " + Integer.toString(pivot));
        if (pivot == -1) {
            return Arrays.binarySearch(list, 0, list.length, key);
        }
        if (list[pivot] == key) {
            return pivot;
        }
        //Split the array into two sub arrays
        if (list[0] <= key) {
            return Arrays.binarySearch(list, 0, pivot - 1, key);
        }
        return Arrays.binarySearch(list, pivot + 1, list.length - 1, key);
    }

    /**
     *
     * @param list array of integers
     * @param left left half
     * @param right right half
     * @return pivot found
     */
    static int findPivot(int[] list, int left, int right) {
        if (list[left] < list[right]) //Array is not rotated
        {
            return -1;
        }
        if (right == left) //Only on element in the array
        {
            return left;
        }
        int middle = (left + right) / 2; //Find mid point
        print("Middle: " + Integer.toString(middle));
        if (list[middle] < list[middle + 1] && list[middle] < list[middle - 1]) {
            return middle;
        }
        if (list[middle] > list[middle + 1]) {
            return middle + 1;
        }
        if (list[left] <= list[middle]) {
            left = middle + 1;
            return findPivot(list, left, right);
        } else {
            right = middle - 1;
            return findPivot(list, left, right);
        }
    }

    static void printList(int[] list) {
        for (int e : list) {
            System.out.print(e + " ");
        }
        System.out.println("");
    }

    static void print(String s) {
        System.out.println(s);
    }

    public static void main(String[] args) {
        int[] numListOne = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int[] numListTwo = {3, 4, 5, 6, 7, 8, 9, 10, 1, 2};
        int[] numListThree = {15, 16, 19, 20, 25, 1, 3, 4, 5, 7, 10, 14};
        print("--------------------------------");
        print("List number one");
        printList(numListOne);
        print("Number 5 is in index: " + Integer.toString(search(numListOne, 5)));
        print("--------------------------------");
        print("List number two");
        printList(numListTwo);
        print("Number 5 is in index: " + Integer.toString(search(numListTwo, 5)));
        print("--------------------------------");
        print("List number three");
        printList(numListThree);
        print("Number 5 is in index: " + Integer.toString(search(numListThree, 5)));
        print("--------------------------------");

    }
}
